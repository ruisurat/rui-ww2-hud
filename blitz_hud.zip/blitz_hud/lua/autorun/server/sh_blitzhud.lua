resource.AddFile("resource/fonts/Futura.ttf")
resource.AddFile("materials/bf1hudhp.png")
resource.AddFile("materials/bf1hudgrenade.png")