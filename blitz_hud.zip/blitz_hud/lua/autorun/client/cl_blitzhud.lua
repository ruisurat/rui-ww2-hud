-- include("autorun/server/sh_blitzhud.lua")

surface.CreateFont("MainFont",{
	font = "Futura Book",
	extended = false,
	size = 20,
	weight = 100,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})

surface.CreateFont("BottomFont",{
	font = "Futura",
	extended = false,
	size = 20,
	weight = 100,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})

surface.CreateFont("DEAD",{
	font = "Futura Book",
	extended = false,
	size = 30,
	weight = 100,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})

surface.CreateFont("Reserved",{
	font = "Futura Book",
	extended = false,
	size = 25,
	weight = 100,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = true,
	additive = false,
	outline = false,
})

surface.CreateFont("OverheadFont",{
	font = "Futura Book",
	extended = false,
	size = 30,
	weight = 100,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = true,
	additive = false,
	outline = false,
})

surface.CreateFont("OverheadFont2",{
	font = "Futura Book",
	extended = false,
	size = 25,
	weight = 100,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = true,
	additive = false,
	outline = false,
})

local hints = {
    "Hint 1",
    "Hint 2",
}

local commonwealth = {
	TEAM_77IDRIFLEMAN,
	TEAM_77IDMED,
	TEAM_77IDENGINEER,
}

local unitedStates = {}

local germanArmy = {
}

local curHint = ""

hook.Add("HUDPaint", "BlitzHud", function()

    local scrw, scrh = ScrW(), ScrH()
    local ply = LocalPlayer()
    local trace = ply:GetEyeTrace()
    local ent = trace.Entity 

    if !ply:Alive() then
        draw.SimpleText("Killed In Combat", "DEAD", ScrW() - 950, ScrH() - 550, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_MIDDLE)
        draw.SimpleText("", "Trebuchet18", ScrW() - 950, ScrH() - 520, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_MIDDLE)
        return
    end

	local hp = ply:Health()


    draw.RoundedBox(2, 10, ScrH() - 145, 270, 30, Color(0, 0, 0, 225))
    if (string.len(ply:Nick()) <= 30) then
        draw.SimpleText(ply:Nick(), "MainFont", 20, ScrH() - 140, Color(255, 255, 255))
    else
        draw.SimpleText(string.sub(ply:Nick(), 0, 30) .. "...", "MainFont", 20, ScrH() - 140, Color(255, 255, 255))
    end
    draw.RoundedBox(2, 10, ScrH() - 115, 270, 70, Color(30, 30, 30, 150))
    draw.RoundedBox(2, 20, ScrH() - 105, 250, 7, Color(0, 0, 0, 210))
    if (hp >= 100) then
        draw.RoundedBox(2, 20, ScrH() - 105, 250, 7, Color(255, 255, 255, 255))
    end

    if (hp < 100) then
        draw.RoundedBox(2, 20, ScrH() - 105, ply:Health() * 2.5, 7, Color(255, 255 * ply:Health() * 0.01, 255 * ply:Health() * 0.01, 255))
    end
    
    draw.RoundedBox(2, 20, ScrH() - 95, 250, 7, Color(0, 0, 0, 210))
    draw.RoundedBox(2, 20, ScrH() - 95, ply:Armor() * 2.5, 7, Color(52, 152, 219, 150))
    --draw.SimpleText("77th Infantry Division | Rifleman", "BottomFont", 20, ScrH() - 75, Color(22, 160, 133)) 
    draw.SimpleText("Loadout Points: "..string.Comma(ML.Credits), "Trebuchet18", 20, ScrH() - 80, Color(255, 255, 255)) 
    draw.SimpleText("Roleplay Rank: "..ply:GetJobRankName(), "Trebuchet18", 20, ScrH() - 65, Color(255, 255, 255)) 

    if ply:GetActiveWeapon() and IsValid(ply:GetActiveWeapon()) and !ply:InVehicle() then
        local weapon = ply:GetActiveWeapon()
        local mag = weapon:Clip1()
        local reserved = ply:GetAmmoCount(weapon:GetPrimaryAmmoType())

        if mag > 999 then
            mag = 999
        end

        if reserved > 999 then
            reserved = 999
        end

        draw.RoundedBox(2, ScrW() - 210, ScrH() - 145, 200, 30, Color(0, 0, 0, 170))
        draw.RoundedBox(2, ScrW() - 110, ScrH() - 115, 100, 40, Color(30, 30, 30, 150))
        
        if (mag < 0) then
            draw.SimpleText("Melee", "Reserved", ScrW() - 20, ScrH() - 110, Color(231, 76, 60), TEXT_ALIGN_RIGHT)
        end
        
        if (mag == 0 and reserved == 0) then
            draw.SimpleText(mag .. "/" .. reserved, "Reserved", ScrW() - 20, ScrH() - 110, Color(231, 76, 60), TEXT_ALIGN_RIGHT)
		elseif (mag > 0 and reserved > 0 or mag >= 0 and reserved >= 0) then
            draw.SimpleText(mag .. "/" .. reserved, "Reserved", ScrW() - 20, ScrH() - 110, Color(255, 255, 255), TEXT_ALIGN_RIGHT)
        end
        draw.SimpleText(weapon:GetPrintName(), "MainFont", ScrW() - 20, ScrH() - 140, Color(255, 255, 255), TEXT_ALIGN_RIGHT)
    end
            

    local width = ScrW()
		local height = ScrH()-15
		local ang = ply:EyeAngles()
		ang:Normalize()

		local CompassDirections = {
			"N",
			"NE",
			"E",
			"SE",
			"S",
			"SW",
			"W",
			"NW"
		}
		
		local deg = math.ceil(ang.y - 90)

		while deg < 360 do 
			deg = deg + 360 
		end

		while deg > 0 do 
			deg = deg - 360 
		end

		compasspad = 0 - width
		compasswidth = ScrW()
		
		local i = 1
		local directioncounter = 3

		render.SetScissorRect(width + compasspad, height, width + compasspad + compasswidth, height + 20, true)
		
		width = width + math.Round(compasspad - compasswidth * 3 / 2)
		width = width + ang.y / 180 * compasswidth

		draw.RoundedBox(0, 0, height, ScrW(), 15, Color(0, 0, 0, 0))

		while i <= 18 do
			local txt = CompassDirections[directioncounter]

			draw.SimpleText(txt, "Trebuchet24", width, height - 7, compassBarFontColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

			width = width + math.Round(compasswidth / 4)
			i = i + 1
			directioncounter = directioncounter + 1

			if directioncounter > #CompassDirections then
				directioncounter = 1
			end
		end

end)


local HideElementsTable = {
    ["DarkRP_HUD"] = true,
    ["DarkRP_EntityDisplay"] = true,
    ["DarkRP_ZombieInfo"] = true,
    ["DarkRP_LocalPlayerHUD"] = true,
    ["DarkRP_Hungermod"] = true,
    ["DarkRP_Agenda"] = true,

    ["CHudHealth"] = true,
    ["CHudBattery"] = true,
    ["CHudAmmo"] = true,
    ["CHudSuitPower"] = true,
}

local function HideElements( element )
    if HideElementsTable[element] then
        return false
    end
end
hook.Add("HUDShouldDraw", "HideElements", HideElements)

hook.Add("PostPlayerDraw", "TargetID", function( ply )
	if !ply:Alive() then
		return
	end

	if ply:GetRenderMode() == RENDERMODE_TRANSALPHA then
		return
	end

	local distance = LocalPlayer():GetPos():Distance(ply:GetPos())
	local displayAng = LocalPlayer():EyeAngles()
	local displayPos = ply:GetPos() + Vector(0, 0, 80)
	local trace = LocalPlayer():GetEyeTrace()

	if ply != LocalPlayer() then
		cam.Start3D2D(displayPos, Angle(0, displayAng.y - 90, 90), 0.15)
			if distance < 400 then
				draw.SimpleText(ply:Nick(), "OverheadFont", 0, 0, Color(255, 255 * ply:Health() * 0.01, 255 * ply:Health() * 0.01, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				if (table.HasValue(commonwealth, ply:Team())) then
					draw.SimpleText("Commonwealth " .. ply:GetJobRankName(), "OverheadFont2", 0, 30, Color(47, 143, 54, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				elseif (table.HasValue(unitedStates, ply:Team())) then
					draw.SimpleText("American " .. ply:GetJobRankName(), "OverheadFont2", 0, 30, Color(47, 143, 54, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				elseif (table.HasValue(germanArmy, ply:Team())) then
					draw.SimpleText("German " .. ply:GetJobRankName(), "OverheadFont2", 0, 30, Color(125, 17, 17, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				elseif !(table.HasValue(commonwealth, ply:Team())) and !(table.HasValue(unitedStates, ply:Team())) and !(table.HasValue(germanArmy, ply:Team())) then
					draw.SimpleText("No Affiliation", "OverheadFont2", 0, 30, Color(0, 174, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				end
			end
		cam.End3D2D()
	end
end)

hook.Add("HUDDrawTargetID", "StopDrawing", function()
	return false
end)

hook.Add("DrawDeathNotice", "HideDeath", function()
	return false
end)