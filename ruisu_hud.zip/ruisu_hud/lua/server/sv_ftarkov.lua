

hook.Add( "PlayerSpawn", "Stamina_Default", function( ply )
	ply.DefRun = ply:GetRunSpeed()
	ply.DefWalk = ply:GetWalkSpeed()
	ply.DefJump = ply:GetJumpPower()
end )


//Regen


	
	
hook.Add( "PlayerTick", "Stamina_System", function( ply )
	local health = ply:Health()
	
	if !ply:Alive() then return end
	if !ply:OnGround() then 
		regen = 0.02
	else if ply:IsSprinting() then
	regen = 0
    else regen = 0.04
	
	end
	end	
	
	//Stamina+
    ply:SetNWFloat( "ForceStamina", math.Clamp( ply:GetNWFloat( "ForceStamina", ply:GetNWInt( "DEFAULT.Stamina", 100 ) ) + regen, 0, 100 ) )
	//Stamina-
	if ply:IsSprinting() and ply:GetVelocity():Length() >= ply.DefRun and ply:OnGround() then
		ply:SetNWFloat( "ForceStamina", math.Clamp( ply:GetNWFloat( "ForceStamina" ) - 0.1, 0, 100 ) )
         end	
	
	force_stamina = ply:GetNWFloat("ForceStamina")
	
	//Spurt
	//PauseWalk 
	
	if force_stamina <= 45 then
            if !ply:IsSprinting()  then
	          ply:SetWalkSpeed( ply.DefWalk * 0.5 )
	          ply:SetRunSpeed( ply.DefWalk  * 0.5 )		  
	          ply:SetJumpPower( ply.DefJump * 0.05 )
			end
	else
      	ply:SetWalkSpeed( ply.DefWalk )  
        ply:SetRunSpeed( ply.DefRun )
	    ply:SetJumpPower( ply.DefJump )
	 end
	 
	//Damage
	if force_stamina <= 15 then
		ply:SetRunSpeed( ply.DefWalk  * 0.2 )
		ply:SetWalkSpeed( ply.DefWalk * 0.2 )	
		  if health > 20 then 
    
			  end
	      end
	//Unknown Jump
	if force_stamina <= 8 then
		ply:SetRunSpeed( ply.DefWalk  * 0.05 )
	    ply:SetWalkSpeed( ply.DefWalk * 0.05 )		
			 end
	      
     //Prone

	 //Seat
	 
	//Blood add
//	if health >= 30 then timer.Remove( "UNREGEN"..ply:UserID())	 
//    end 
	
	
	
	
end )


//hook.Add( "EntityTakeDamage", "Blood_system", function( ply )
//  local health = ply:Health()
//  if health < 30 then
//  timer.Create( "UNREGEN"..ply:UserID(), 1, 0, function() 
//	ply:SetHealth(ply:Health() - 5) 
//	PrintMessage(HUD_PRINTTALK,"Time ///")
//	 end)	
// end	 
//end)


hook.Add( "VehicleMove","Stamina_Vehicle" , function( ply )
    ply:SetNWFloat( "ForceStamina", math.Clamp( ply:GetNWFloat( "ForceStamina", ply:GetNWInt( "DEFAULT.Stamina", 100 ) ) + regen, 0, 100 ) )
	if ply:InVehicle() then
	regen = 0.24
	end
end )

hook.Add( "KeyPress", "Stamina_Jump", function( ply, key )
	if !ply:Alive() then return end
	if !ply:OnGround() then return end
	if ply:InVehicle() then return end
	if key == IN_JUMP then
		ply:SetNWFloat( "ForceStamina", math.Clamp( ply:GetNWFloat( "ForceStamina" ) - 10, 0, 100 ) )
	end 
	end )
 

	   

hook.Add( "PlayerDeath", "ResetStamina", function( ply )

	ply:SetNWFloat( "ForceStamina", 100 )


	end )