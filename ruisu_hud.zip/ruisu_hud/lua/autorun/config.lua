--V0.12
  // BASE CONFIG
  
//prone mod == 0 - false // 1 true (def.1)
  fprone = 1
//custom blood == 0 - false // 1 true (def.0)
  fblood = 1
//custom stamina == 0 - false // 1 true (def.1)
  fstamina = 1  //(DEV)

// style hud 0 - Classical // 1 New De
  fStyleHud = 0
   
 // вкл. лі левая полосочка позіцій? == 0 - false // 1 true (def.1)
  fLeftLine = 1
//Значение верх.полосочки 0 - stamina // 1 - armor // 2 - off
  fUpLine = 0
//Значение нижней.полосочки 0 - health // 1 - stamina // 2 - off (def.0)
  fDownLine = 0
//Значение над - нижней.полосочки 0 - armor // 1 - off (def.0)
  fExt_DownLine = 0
  

  
 
  // if icon off then fLeftLine also but not Vice versa
  fIconTactical = 1
  
  
  
  fspecial_effect = 0 //(DEV)


 // - ammo
  // Включено лі інтерфейс патрон //0 - on // 1 - off (def.0)
   fAmmoMenu = 1
  // надо лі зажімать комбінацію клавіш чтоб увідеть патроны 0 - false // 1 - true
    fAmmoExt = 0 
	
	//Еслі да то какіе 
	--DEV
	
	// 0 - small left // 1 - large right
    fAmmoPosition = 0
	// Патроны в резерве показаны 0 - кол-во // 1 в магазінах
	fAmmoRes = 1
	// Когда закончілісь патроны  0 - квадрат становітся красным  //  1 - - квадрат пропадает 
	fAmmoEmpty = 0
  // DARK RP CONFIG
  
  
  
  
  
  ////////////////////////
  
  //position - custom position