

resource.AddFile("materials/tseat.png")
resource.AddFile("materials/tstay.png")
resource.AddFile("materials/tprone.png")


if SERVER then
   include ( 'server/sv_ftarkov.lua' )
   
   AddCSLuaFile( 'client/cl_ftarkov.lua' )
  
   end
  
if CLIENT then
   include( 'client/cl_ftarkov.lua' )
   
   end