

hook.Add( "HUDPaint", "DrawT", function()


//Stamina + ReStamina


// next
//draw.RoundedBox(1, 860, ScrH()-305, 260, 60, Color(89, 88, 88, 206))
//draw.RoundedBox(1, ScrW()-230, 455, 200, 50, Color(89, 88, 88, 206))



end )


surface.CreateFont( "Pmd", {
	font = "Arial",
	extended = false,
	size = 24,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,

} )

surface.CreateFont( "tbase_arrow", {
	font = "Arial",
	extended = false,
	size = 12,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,

} )

surface.CreateFont( "tbase_f24", {
	font = "Arial",
	extended = false,
	size = 24,
	weight = 500,
	antialias = true,

} )

surface.CreateFont( "tbase_f21", {
	font = "Arial",
	extended = false,
	size = 21,
	weight = 500,
	antialias = true,

} )

surface.CreateFont( "tbase_f32", {
	font = "Arial",
	extended = false,
	size = 32,
	weight = 500,
	antialias = true,

} )

surface.CreateFont( "new_tbase_f32", {
	font = "1_EFT_by_iWolf Regular",
	extended = false,
	size = 32,
	weight = 500,
	antialias = true,

} )

surface.CreateFont( "new_tbase_f24", {
	font = "1_EFT_by_iWolf Regular",
	extended = false,
	size = 24,
	weight = 500,
	antialias = true,

} )

surface.CreateFont( "new_tbase_f12", {
	font = "1_EFT_by_iWolf Regular",
	extended = false,
	size = 12,
	weight = 500,
	antialias = true,

} )

hook.Add( "HUDPaint", "DrawTarkovS", function()	
//	draw.RoundedBox(360, 330, ScrH()-105, 80, 80, Color(50, 50, 50, 237))	
	//local 
	
	local ply = LocalPlayer()
	
    if !ply:Alive() then return end
	
	local wep = LocalPlayer():GetActiveWeapon()
	local green = 62
	local hudStamina = ply:GetNWFloat( "ForceStamina" )
    local Speed = ply:GetNWFloat( "Speed" )
	local AlphaK = -hudStamina+85 
	local square = 45;
    local health = ply:Health()
	local armor = ply:Armor() 
          green = 100*hudStamina/green
		  
		  
    local name = ply:Name()
    local alive = ply:Alive() 
	
	
	local wep = ply:GetActiveWeapon()

	local wep_name = "Unknown"
	if ply:GetActiveWeapon().GetPrintName then
		wep_name = ply:GetActiveWeapon():GetPrintName()
	end
	
	local wep_ammo = 0
	if ply:GetActiveWeapon().Clip1 then
		wep_ammo = ply:GetActiveWeapon():Clip1() 
	end
	
	local wep_ammo_res = 0
	if wep.GetPrimaryAmmoType then
		wep_ammo_res = ply:GetAmmoCount(wep:GetPrimaryAmmoType())
	end
	
 	local wep_ammo_max = 0
	if ply:GetActiveWeapon().GetMaxClip1 then
		wep_ammo_max = ply:GetActiveWeapon():GetMaxClip1()
	end       
	local wep_mag = math.floor(wep_ammo_res/wep_ammo_max)	  

	///////////////////////	    
	// local config
	local pos_arrow
	
	if (fprone == 1) then pos_arrow = 150
	else pos_arrow = 73 end;
	
	local low_line
	if (fDownLine == 0) then low_line = health 
	 else if (fDownLine == 1) then low_line = hudStamina
	 else low_line = 0
	 end
	end
		  
	local up_line
	if (fUpLine == 0) then up_line = hudStamina
	 else if (fUpLine == 1) then up_line = armor
	 else up_line = 0
	 end
	end		  
	///////////////////////	  
   ///////////////////////	
	
		  if ply:Health() > 100 then
		     health = 100
			end
			 
			 if ply:Armor() > 100 then
		     armor = 100
			end		
		  
 ///////////////////////	LINES ///////////////////////	
		 
		 	
			// UP LINE   
	if fUpLine < 2 then
		if fStyleHud == 0 then
			local ind_sta =  285 * up_line / 100
			draw.RoundedBox(1, 40, ScrH()-55, 285, 7 , Color(103, 103, 103, 245))
			draw.RoundedBox(1, 40, ScrH()-55, ind_sta , 7 , Color(213, 213, 213, 245))
			draw.DrawText("▼", "tbase_arrow", ind_sta + 33, ScrH()-68, Color(172,172,172, 247))
			
			for i = 1, 14 do
				draw.RoundedBox(1, square, ScrH()-55, 15, 7 , Color(63, 63, 63, 245))
				square = square + 20;
			end	
			 
		else 
				local tlon_long_dark = Material("materials/tlon_long_dark.png");
				surface.SetMaterial(tlon_long_dark); 
				surface.SetDrawColor(255,255,255,255)			
				surface.DrawTexturedRect(19, ScrH()-58, 337, 13)	
				draw.RoundedBox(1, 44, ScrH()-54, 287 * up_line / 100, 5, Color(34, 103, 92, 227))
		 end
		 
	end
		  // LOW LINE
		  if fStyleHud == 0 then
			draw.RoundedBox(1, 37, ScrH()-38, 287, 13, Color(80, 80, 80, 255)) 
			draw.RoundedBox(2, 38, ScrH()-36, 284, 9, Color(2, 2, 2, 245))	
            draw.RoundedBox(1, 40, ScrH()-35, 280 * low_line / 100, 7, Color(34, 103, 92, 227))			
		  else 			
			local tlon_long_dark = Material("materials/tlon_long_dark.png");
			surface.SetMaterial(tlon_long_dark); 
			surface.SetDrawColor(255,255,255,255)	
			surface.DrawTexturedRect(19, ScrH()-38, 337, 13)	
	        draw.RoundedBox(1, 44, ScrH()-34, 287 * low_line / 100, 5, Color(34, 103, 92, 227))
		end
		 
	     
         
		 if (fExt_DownLine == 0) then		 
			draw.RoundedBox(1, 40, ScrH()-35, 280 * armor / 100, 7, Color(0,0,128, 107))	           
         end
           
         // LEFT LINE
         if (fLeftLine == 1 and fIconTactical == 1)  then
		  
		  draw.RoundedBox(0, 50, ScrH()-225, 8, 160, Color(41, 41, 41, 205))
		  draw.RoundedBox(0, 50, ScrH()-225, 8, 8, Color(141, 141, 141, 205))
		  
		   if (fprone == 1) then
		    draw.RoundedBox(0, 50, ScrH()-150, 8, 8, Color(141, 141, 141, 205))
		   end		  
		  draw.RoundedBox(0, 50, ScrH()-73, 8, 8, Color(141, 141, 141, 205))
		 end
//////////////////////////////////////////////	
		 //Ammo // DEVELOPIMH
 
	if  alive and fAmmoMenu == 0 then 
 
		local wep_p1 = 1.546
		local font_ammo_size = "tbase_f24"
		if (wep_ammo < 10) then
			wep_p1 = 1.538
		end  
		
		local wep_p2 = 1.479
		
		if (fAmmoRes == 1) then		
			wep_p2 = 1.476
			if (wep_mag >= 10 and wep_mag < 100) then
				wep_p2 = 1.483
			end		
			if (wep_mag >= 100) then
				wep_p2 = 1.487
				font_ammo_size = "tbase_f21"		
			end	
		end
		
		if (fAmmoRes == 0) then	    
			if (wep_ammo_res >= 10 and wep_ammo_res < 100) then
				wep_p2 = 1.484
			end
			if (wep_ammo_res >= 100) then
					wep_p2 = 1.485
					font_ammo_size = "tbase_f21"
					
			end	
		end	
		
		local reserv_ammo
		if(fAmmoRes == 1) then
			reserv_ammo = wep_mag
		else 
			reserv_ammo = wep_ammo_res
		end
		
		
		local tsqr = Material("materials/tsqr.png");
		local tsqr_dark = Material("materials/tsqr_dark.png");
		local tsqr_true = tsqr_dark
		
		if (wep_ammo == 0 and fAmmoEmpty == 0) then	
		tsqr_true = tsqr
		end
		
		surface.SetMaterial(tsqr_true); 
		surface.SetDrawColor(255,255,255,235)	 

		if (wep_ammo >= fAmmoEmpty ) then
		surface.DrawTexturedRect(ScrW()/1.58, ScrH()-85, 70, 70)	
		draw.DrawText(wep_ammo, "tbase_f32", ScrW()/wep_p1, ScrH()-67, Color(172,172,172, 247))  
		end
		
		surface.SetMaterial(tsqr_dark); 
		if (wep_mag >= 1) then  --FIX THEM
		surface.DrawTexturedRect(ScrW()/1.5, ScrH()-55, 52, 52)				 
		draw.DrawText(reserv_ammo, font_ammo_size, ScrW()/wep_p2, ScrH()-40, Color(172,172,172, 247)) 
		end

		
				 
			
		
		local tlon_dark = Material("materials/tlon_dark.png");
		surface.SetMaterial(tlon_dark); 
		surface.SetDrawColor(255,255,255,235) 
		surface.DrawTexturedRect(ScrW()/1.464, ScrH()-91, 170, 50)		 
		--wep-name
		draw.DrawText(wep_name, "tbase_f24", ScrW()/1.44, ScrH()-78, Color(172,172,172, 247))   			 
			 
			 
	end
		//////////////////////////////////////////////	//////////////////////////////////////////////		
		
		// Version Server Tarkov
		
		//draw.DrawText("Tarkov BETA 0.0.3", "PmdBeta", ScrW()/2 , ScrH()/1.04, Color(152,152,152, 157))
		
		 ///////////////////////	ICON POSSS ///////////////////////	  
		 if (fIconTactical == 1) then
	         if ply:IsProne() and fprone == 1 then
	             local tprone = Material("materials/tprone.png");
						surface.SetMaterial(tprone); 
						surface.SetDrawColor(0,0,0,235)
						surface.DrawTexturedRect(65, ScrH()-160, 300, 100)
					    if (fLeftLine == 1) then
						draw.RoundedBox(0, 50, ScrH()-73, 8, 8, Color(251, 251, 251, 205))
						draw.DrawText("►", "tbase_arrow", 38 , ScrH()-75, Color(251, 251, 251, 247))		
		 	             end
						 
				else if (ply:KeyDown(IN_DUCK)) then
					local tseat = Material("materials/tseat.png");
						surface.SetMaterial(tseat); 
						surface.SetDrawColor(0,0,0,235)
						surface.DrawTexturedRect(70, ScrH()-260, 150, 190)
						if (fLeftLine == 1) then
				        draw.RoundedBox(0, 50, ScrH()-pos_arrow, 8, 8, Color(251, 251, 251, 205))	
                        draw.DrawText("►", "tbase_arrow", 38 , ScrH()-(pos_arrow+2), Color(251, 251, 251, 247))						
                   			end		
				else
					local tstay = Material("materials/tstay.png");
					surface.SetMaterial(tstay); 
					surface.SetDrawColor(0,0,0,235)
					surface.DrawTexturedRect(70, ScrH()-245, 160, 190)
					if (fLeftLine == 1) then
						draw.RoundedBox(0, 50, ScrH()-225, 8, 8, Color(251, 251, 251, 205))
						draw.DrawText("►", "tbase_arrow", 38 , ScrH()-227, Color(251, 251, 251, 247))
					end							
				end	             
             end
          end 
 /////////////////////// ///////////////////////	

//  UPDATE 




 
 
 //REWORK COMING SOON
 
  local posH = ScrH()/2-420
 local posH2 = ScrH()/2-380
 
 if ply:InVehicle() then
 
draw.RoundedBox(0, ScrW()/8-210, posH, 30, 30, Color(255,215,0, 209))
draw.RoundedBox(0, ScrW()/8-180, posH, 140, 30, Color(62, 62, 62, 182))
draw.RoundedBox(0, ScrW()/8-180, posH+25, 140, 5, Color(32, 32, 32, 170))

	draw.DrawText("In Vehicle", "Pmd", ScrW()/8-170, ScrH()/2-418, Color(210,210,210, 240))
end
 
 if health < 30 and ply:Alive() then
 if !ply:InVehicle() then posH2 = posH end 
draw.RoundedBox(0, ScrW()/8-210, posH2, 30, 30, Color(255,99,71, 232))
draw.RoundedBox(0, ScrW()/8-180, posH2, 140, 30, Color(62, 62, 62, 182))
draw.RoundedBox(0, ScrW()/8-180, posH2+25, 140, 5, Color(32, 32, 32, 170))
draw.DrawText("Bleeding", "Pmd", ScrW()/8-176, posH2, Color(210,210,210, 240))
 end


 
 


 ///////////////////////    EFFECT SCREEN  ///////////////////////	
	local yopta = health / 10;
	local yopta_v2 = health / 100

	local ts = {
	[ "$pp_colour_addr" ] = 0.00,
	[ "$pp_colour_colour" ] = yopta_v2,
	[ "$pp_colour_mulr" ] = yopta,
	[ "$pp_colour_brightness" ] = 0.1,
	[ "$pp_colour_contrast" ] = 1,
}
	local ts1 = {
		[ "$pp_colour_colour" ] = 10,
	}					 
			             if (health < 55) then 
		             	 DrawColorModify( ts )
						 end
						 
					    if (health < 15) then 
		             	 DrawColorModify( ts1 )
						 end
						 
	//blur
                        



						if (hudStamina < 40) then
						  DrawMotionBlur( 0.4, 0.8, 0.01 )
						  end
						  
						  
						  if (hudStamina < 18) then
                          DrawToyTown( 20, ScrH()/1.5 )
						  else if (hudStamina < 30 and hudStamina > 18) then
						  DrawToyTown( 3, ScrH()/1.5 )
						  else if (hudStamina < 40 and hudStamina > 30) then
						  DrawToyTown( 1, ScrH()/1.5 )
						  end
						  end
						end 
   
   
    
   
  
	end )


// 37 36 35 - E
	
	local hideHUDElements ={
   ["DarkRP_HUD"]             =true,
   ["DarkRP_EntityDisplay"]   =false,
   ["DarkRP_ZombieInfo"]     =false,
   ["DarkRP_LocalPlayerHUD"]=true,
   ["DarkRP_Hungermod"]       =true,
   ["DarkRP_Agenda"]         =false
}

	local def_hide = {
	["CHudHealth"] = true,
	["CHudBattery"] = true,
	["CHudAmmo"] = true,
	["CHudSecondaryAmmo"] = true
}

function disableDefault( name )
	if ( def_hide [ name ] ) then return false end
end

hook.Add("HUDShouldDraw","HideDefaultDarkRPHud",function(name)
   if hideHUDElements[name]then return false end
end)

hook.Add("PostPlayerDraw","TarkovID",TarkovTargetID)

hook.Add("HUDShouldDraw", "HideDefaultHuds", disableDefault)	